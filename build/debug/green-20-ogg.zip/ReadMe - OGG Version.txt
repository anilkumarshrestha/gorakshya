===========================================================================
=================== ENGLISH (VERSION FRANCAISE EN BAS) ====================
===========================================================================

GENERAL INFORMATION ABOUT THIS MUSIC
---------------------------------------------------------------------------

"Green Hills" (Duration/Playing Time: 08:14)
Copyright (C) 2002-2007 Maxime Abbey
Version 2.0 (2007-05-31)

Along with "Arabian Feelings", this song remains one of my favourites among
all my personal works. More than five years after the release of the first
version, here is a new, entirely reworked-from-scratch track, based on that
same little melody you may either love... or hate :)

The first version, as most of my early works, was a very repeative mix of
melodies. With this new version, I wanted to keep the same ideas, while
introducing some new stuff, which you'll discover when looking after the
first two minutes of the song.

Just like with "Arabian Feelings", I tried to split this song into several
parts, either by using different instruments, or by covering different
registers.

If I had to credit someone who inspired me parts of this song, it would
be, once again, Karsten Koch, with his excellent "Hidden Empire" track.
If you like my song, you may also like his one, so, try it out!

TECHNICAL INFORMATION ABOUT THIS MUSIC & WHAT YOU NEED TO USE IT
---------------------------------------------------------------------------

This music has been originally created and saved with OpenMPT 1.17.02.48 in
ImpulseTracker (IT) compatible format. It uses 20 channels, 23 instruments
and 46 samples.

This file has been rendered from the above-mentioned IT version, first in
high-quality WAVE lossless format using OpenMPT 1.17.02.48, then converted
into compressed OGG Vorbis format (quality 7, average bitrate of 210 kbps)
using Audacity 1.3.3 and Xiph.Org libVorbis I 20050304.

It aims to provide a more common format, for your convenience, because of
its usability in any OGG Vorbis compatible software (such as Winamp) or
hardware (portable audio players, car audio...). Unless explicitly noted,
it sounds identical to the original IT version available on my website,
except for the lossy compression of the OGG Vorbis format.

TOOLS & AUDIO GEAR USED
---------------------------------------------------------------------------

As stated above, this music has been entirely composed and produced with
OpenMPT 1.17.02.48.

ALL instruments used have been built and recorded by myself, with a Sound
Blaster Live! 5.1 soundcard, in "dry" 16-bit/48 KHz sound quality.

The samples either come from my hardware MIDI synths, or from my own
SoundFont bank, which I've been working on since 2003, to enhance the
sounds of my MIDI files, and to give me new material to compose music.

As a result, if you want to use one or more of those samples in your own
creations, you must contact me first, as described by the terms of use of
the license (see further down in this document).

Most of my SoundFont bank is based on other SoundFonts (particularly Magic
SoundFont 2.0, Unison, Fluid 3) but all its instruments have been enhanced
and modified to produce more original sounds. It uses many Roland sounds
but also has many Korg and Yamaha sounds.

This music, of course, only uses a partial set of all the sounds I've
developed for my own bank. You'll find below a detailed list of the samples
I've used.

DETAILED INFORMATION ABOUT THE SOUNDS USED IN THIS MUSIC
---------------------------------------------------------------------------

- The "Synth Bass 2" is a combination of several synth bass patches which
can be found on several MIDI synths, including Yamaha MU and Roland Sound
Canvas Series. I've recorded parts of it from my own Roland Sound Canvas
SC-8850 MIDI expander.

- Just like the above, the "Synth Bass 1" is a mix of several Moog-style
synth bass sounds. I've also built this one with samples mainly recorded
from my own SC-8850 expander.

- The "Strings" used in this song have been built from many sources as
well, the most predominant being a set of Kurzweil PC-88 Marcato Strings.

- The "Laser Sweep" used for the main melody is a sweet mix of two famous
80's sounds, one being extracted from the Jazz Jackrabbit game music files,
and the other one being the very famous "Laser Harp" used by Jean(-)Michel
Jarre in some of his best songs, most notably "Second Rendez-vous". These
two have been mixed with the Poly Synth I made for my MIDI SoundFont bank
to add some texture on the instrument.

- The "Atmosphere" pad is an exact rendering of the one I use in my General
MIDI bank, being composed of several sounds including harp, synth strings,
Roland U-20 electric pianos, nylon-string acoustic guitar sounds by Mats
Helgesson and, as the main texture pad, two sounds from the very famous
Roland D-50: "Pizzagogo" and "Nylon Sphere".

- The "Brightness" has also been directly rendered from my SoundFont bank.
This instrument is a combination of synth voices, including that famous
Fairlight CMI IIx "Arr1" synth sample voice (heavily used in the 80's, and
as the synth voice patch of the Gravis UltraSound cards), mixed with some
rock organs (including a sample by Johannes Roussel), synth strings and,
as the mainstream instruments, the "Fresh Air" preset from the Korg X5(DR)
series (recorded by myself) and the famous "Staccato Heaven" pad from the
Roland D-50.

- The "Celesta" is an instrument I took from the "Magic SoundFont" bank,
slightly modified to be included afterwards in my own one.

- The "Percussive Organ" is an exact rendering of my own Korg X5DR's
percussive organ (this instrument was also available on the more famous
Korg M1), layered with some other percussive organ sounds (including the
one available on the Roland Sound Canvas SC-55) to add some punchy effect.

- The "Voice Oohs" is a somewhat realistic-sounding mix of male and female
"oooh" voices, obtained from the "voice oohs" sounds of the Kurzweil K2500
synthesizer combined with some slightly different "voice oohs" sounds from
the "Magic SoundFont" bank.

- The "M1 Doo Voice" is, as its name indicates, a quite well-known
instrument directly rendered from the famous Korg M1 synthesizer. As a
sidenote, I think that this sound has also been used, among others, in the
main level track of the Super Mario 64 video game. Check it out! :)

- All the "standard" percussion sounds, as well as the power ride cymal,
come from my own SoundFont bank. These "standard" acoustic bass drum and
snare sets have been quite popular among SoundFont users, and can be found
as the main drumkit of many GM SoundFonts, including the "Magic SoundFont".

- The "TR-808/909 Kick Drum" has been sampled from several Roland TR-909
sound sources, including samples from my own SoundFont bank and the "Mega
Sound Bank".

- The "SC-8850 Techno Snare" has a name that says it all: it's a sample
I've recorded from my SC-8850 expander, mixed with a TR-909 snare sound to
add some depth to it.

- And, to finish, the toms are a mix of those found in my SoundFont bank
(from the same set as the other "standard" samples described above) and
those available in the Power drum kit of the Roland Sound Canvas series
starting from the SC-88. Hence, I've also sampled these sounds myself.

Read the license and terms of use below for more information about the use
of those sounds.

LICENSE AND TERMS OF USE OF THIS MUSIC
---------------------------------------------------------------------------

* MISCELLANEOUS

This music is distributed for FREE for your personal listening and editing
pleasure.

Anyway, its use implies the acceptance of a license and specific terms
of use, as described below: this music is released as copyrighted under
the "freeware" model, and absolutely not as part of the public domain.

The same terms of license apply to all parts of this music, including
samples and instruments, unless otherwise noted. Keep in mind that those
terms may be modified by myself at any time without any notification. The
official and latest version of this license is available on my website,
located at http://www.arachnosoft.com. Be sure to check it when necessary.

* DISTRIBUTION

You are free to distribute this music to anyone you want, under any format,
as long as you keep the final user informed about the origin of this music,
its author, and its official availability on my website,
http://www.arachnosoft.com.

If you want to distribute this music in another format than the ones I
offer to you (MP3, OGG, etc.), I would like you to contact me before, to
keep me informed on the use of my music.

You are of course free to distribute the original package, as found on my
website. I'd like to be also informed by e-mail if you do so.

In any case, you MUST specify clearly that this music has been produced by
me, Maxime Abbey, and that its original and latest versions are available
on my website, http://www.arachnosoft.com.

Moreover, the distribution must be done freely, or in exchange of a small
amount of money aimed at covering distribution fees and/or supports
(CD-ROM, disks...). Any commercial distribution is covered by the
commercial usage terms of this license, as described below.

* USAGE

You are entirely free to use and listen to this music for your personal
pleasure and to convert in any format to suit your listening needs, as long
as it does not harm anyone and complies with the terms of this license.

If you want to use this music on your own creations (software, website,
CD-ROM, presentation, magazine, etc), whatever is your project, please
contact me to keep me informed about it, even if any use in non-commercial
projects is encouraged. However, any commercial use MUST be discussed with
me before anything. All parts of this music are concerned, even the samples
and the instruments, as, unless otherwise noted, all have been built and
recorded by myself.

You are fully allowed to modify or remix this music as you want, but if you
want to distribute a modified version, you must indicate that you've used
my own work as basis, and that you are the author of this modified version.
Moreover, I would be pleased to be informed about your work.

ABOUT THE AUTHOR
---------------------------------------------------------------------------

My name is Maxime Abbey, I was born on October 28th, 1985 in France.

My website is located at http://www.arachnosoft.com. You'll find there all
my freeware programs (including utilities, 2D and 3D games) and all my
music pieces.

You can contact me by e-mail at contact@arachnosoft.com, for any purposes.
Don't hesitate to do so, my natal language is French, but you can write me
in English as well. All e-mails will be read, your support is always
appreciated!

TO FINISH...
---------------------------------------------------------------------------

Thanks for listening to my music! I hope you like it...

I would like also to thank all people who created the tools and samples
I've used for this music, especially Olivier Lapicque and the
OpenMPT/ModPlug Software team, as well as Achraf Cherti, who greatly helped
me to enter in the "tracked music" scene.

And of course, thanks to all mentioned or unmentioned people who have
composed the music which has inspired me to produce this one, either
directly or indirectly!

As a final word, all my apologies for any mistakes I made in this English
documentation, as my natal language is French.

ENJOY MY MUSIC! I'M WAITING FOR YOUR COMMENTS...

===========================================================================
================================ FRANCAIS =================================
===========================================================================

INFORMATIONS GENERALES AU SUJET DE CETTE MUSIQUE
---------------------------------------------------------------------------

"Green Hills" (Dur�e / Temps de Lecture : 08:14)
Copyright (C) 2002-2007 Maxime Abbey
Version 2.0 (31/05/2007)

Tout comme "Arabian Feelings", de toutes mes compositions personnelles,
cette musique reste parmi celles que je pr�f�re. Plus de cinq ans apr�s la
publication de la premi�re version, voici donc une nouvelle mouture
enti�rement refaite � partir de z�ro, bas�e sur cette m�me petite m�lodie,
que vous allez soit adorer... soit d�tester :)

La premi�re version, tout comme la plupart de mes premiers travaux, �tait
un m�lange de m�lodies tr�s r�p�titives. Avec cette nouvelle version, j'ai
souhait� conserver les m�mes id�es, tout en introduisant de nouvelles
s�quences, que vous pourrez d�couvrir en allant au-del� des deux premi�res
minutes du morceau.

De la m�me mani�re qu'avec "Arabian Feelings", j'ai essay� de diviser cette
musique en plusieurs parties, soit en utilisant diff�rents instruments, 
soit en couvrant diff�rents registres musicaux.

Si je devais saluer le travail d'une personne qui m'a inspir� certaines
parties de cette musique, ce serait, une fois encore, celui de Karsten Koch
et de son excellent morceau, "The Hidden Empire". Si vous aimez mon
morceau, il y a de fortes chances que vous appr�ciez celui-ci �galement,
je vous invite donc � l'�couter !

INFORMATIONS TECHNIQUES SUR CETTE MUSIQUE ET COMMENT L'UTILISER
---------------------------------------------------------------------------

Cette musique a �t� cr��e et enregistr�e � l'origine avec OpenMPT
1.17.02.48 en format compatible ImpulseTracker (IT). Elle utilise 20
canaux, 23 instruments et 46 sons.

Ce fichier a �t� enregistr� � partir de la version IT mentionn�e ci-dessus,
tout d'abord en format WAVE haute qualit� sans compression, � l'aide de
OpenMPT 1.17.02.48, puis converti en format OGG Vorbis compress�
(qualit� 7, bitrate moyen de 210 kbps) avec Audacity 1.3.3 et Xiph.Org
libVorbis I 20050304.

Il a pour but de vous fournir un format plus commun, pour votre confort,
car il est utilisable dans tout logiciel (comme Winamp) ou mat�riel
(baladeurs, autoradios...) compatible avec le format OGG Vorbis. Sauf
mention contraire, le son est identique � la version IT d'origine
disponible sur mon site Web, mis � part la compression avec pertes du
format OGG Vorbis.

LOGICIELS & MATERIEL AUDIO UTILISES
---------------------------------------------------------------------------

Comme indiqu� plus haut, cette musique a �t� enti�rement compos�e avec
OpenMPT 1.17.02.48.

TOUS les instruments utilis�s ont �t� construits et enregistr�s par mes
soins, � l'aide d'une carte son Sound Blaster Live! 5.1, en qualit� 16 bits
� 48 KHz. Les sons ont �t� enregistr�es "bruts", sans effets sp�ciaux.

Ils proviennent soit de mes synth�tiseurs MIDI mat�riels, soit de ma propre
banque de sons au format SoundFont, sur laquelle je travaille depuis 2003,
afin d'am�liorer le rendu de mes fichiers MIDI, et pour me donner de
nouveaux sons � utiliser pour composer de nouvelles musiques.

Par cons�quent, si vous souhaitez utiliser un ou plusieurs de ces sons dans
vos propres cr�ations, vous devez me contacter au pr�alable, conform�ment
aux conditions d'utilisation indiqu�es dans la licence (voir plus bas).

Une grande partie de ma banque de sons SoundFont est bas�e sur d'autres
SoundFonts (et plus particuli�rement Magic SoundFont 2.0, Unison, Fluid 3),
mais tous ses instruments ont �t� modifi�s et am�lior�s pour produire des
sons plus originaux. Elle utilise beaucoup de sons Roland mais incorpore
�galement pas mal de sons Korg et Yamaha.

Bien entendu, cette musique n'utilise qu'une partie des sons que j'ai
d�velopp�s pour ma propre banque de sons. Vous trouverez ci-dessous une
liste d�taill�e des sons que j'ai utilis�s.

INFORMATIONS DETAILLEES A PROPOS DES SONS UTILISES DANS CETTE MUSIQUE
---------------------------------------------------------------------------

- La basse synth�tique "Synth Bass 2" est une combinaison de plusieurs
sons de basse synth�tique pr�sents sur plusieurs synth�tiseurs MIDI,
dont les s�ries MU de Yamaha et Sound Canvas de Roland. J'ai enregistr�
une partie de ces sons � partir de mon propre Roland Sound Canvas SC-8850.

- Tout comme la basse mentionn� ci-dessus, "Synth Bass 1" est un m�lange
de plusieurs sons de basse synth�tique type Moog. Je l'ai �galement cr��e
� partir de sons principalement enregistr�s depuis mon SC-8850.

- Les nappes ("Strings") utilis�es dans cette musique ont �galement �t�
cr��es depuis plusieurs sources, la plus omnipr�sente �tant un ensemble de
nappes marcato issues du Kurzweil PC-88.

- Le "Laser Sweep" utilis� pour la m�lodie principale est un m�lange �tudi�
de deux c�l�bres sonorit�s des ann�es 80, une provenant de la bande son du
jeu vid�o Jazz Jackrabbit, et l'autre �tant la tr�s c�l�bre harpe laser
("Laser Harp") utilis�e par Jean(-)Michel Jarre dans ses plus grands
morceaux, et plus particuli�rement dans "Second Rendez-vous". Ces deux sons
ont �t� mix�s avec le Poly Synth que j'ai cr�� pour ma banque SoundFont
afin de donner un peu plus de corps et de texture � l'instrument final.

- Le pad "Atmosphere" est une copie exacte de celui que j'utilise dans ma
banque General MIDI, compos� � partir de plusieurs sons, parmi lesquels
figurent une harpe, des nappes synth�tiques, des pianos �lectriques issus
du Roland U-20, des sons de guitare acoustique � cordes en nylon cr��s par
Mats Helgesson et, comme texture principale, deux sons issus du tr�s
c�l�bre Roland D-50: "Pizzagogo" et "Nylon Sphere".

- Le pad "Brightness" a �galement �t� directement enregistr� � partir de ma
propre banque de sons SoundFont. C'est un m�lange de voix synth�tiques,
comprenant un c�l�bre son issu du Fairlight CMI IIx, "Arr1" (utilis� en
masse durant les ann�es 80, et en tant que voix synth�tiques des cartes son
Gravis UltraSound), le tout m�lang� � des orgues de rock (dont un de
Johannes Roussel), � des nappes synth�tiques et, comme instruments
de t�te, le preset "Fresh Air" des s�ries X5(DR) de Korg (enregistr� par
mes soins) et le c�l�bre pad "Staccato Heaven" du Roland D-50.

- "Celesta" est un autre instrument issu de la banque "Magic SoundFont",
auquel j'ai apport� quelques modifications par la suite afin de l'inclure
dans ma propre banque de sons SoundFont.

- L'orgue � percussions ("Percussive Organ") est une copie exact de celui
pr�sent sur mon Korg X5DR (instrument que l'on pouvait �galement trouver
sur le plus c�l�bre Korg M1), combin� � d'autres sons de percussion d'orgue
(y compris celui pr�sent sur le Roland Sound Canvas SC-55) pour ajouter
une touche de "punch" � l'instrument.

- Les "Voice Oohs" sont un m�lange de voix masculines et f�minines visant �
reproduire un "oooh" plut�t r�aliste. Les sons utilis�s proviennent du
synth�tiseur Kurzweil K2500 et de la banque de sons "Magic SoundFont", qui
offre des "oohs" l�g�rement diff�rents.

- Le preset "M1 Doo Voice" est, comme son nom l'indique, un instrument
plut�t connu du c�l�bre synth�tiseur Korg M1. Petite anecdote, je pense que
ce son a �t� utilis�, entre autres, dans la musique principale du jeu
Super Mario 64. Vous pouvez le v�rifier par vous-m�me ! :)

- Tous les sons de percussion "standard", ainsi que la cymbale "ride", sont
issus de ma banque SoundFont. Ces sons de grosse caisse et de caisse claire
"standard" ont �t� inclus en nombre dans plusieurs SoundFonts GM, y compris
"Magic SoundFont".

- La "TR-808/909 Kick Drum" a �t� enregistr�e � partir de diverses sources,
parmi lesquelles figurent ma propre banque de sons SoundFont et la "Mega
Sound Bank".

- Le "SC-8850 Techno Snare" porte bien son nom : il s'agit d'un son que
j'ai enregistr� � partir de mon SC-8850, m�lang� � un son de caisse
synth�tique �galement issu de la TR-909, afin de donner un peu plus de
profondeur � l'instrument.

- Et, pour terminer, les toms sont issus de m�langes entre ceux pr�sents
dans ma propre banque SoundFont (qui proviennent du m�me kit de percussions
"standard" d�crit plus haut) et ceux utilis�s dans le kit de percussions
Power de la s�rie Sound Canvas de Roland, � partir du SC-88. De ce fait,
j'ai �galement enregistr� ces sons � partir de mon propre expandeur MIDI.

Pour plus d'informations sur l'utilisation de ces sons, lisez la licence et
les conditions d'utilisation d�crites ci-dessous.

LICENCE ET CONDITIONS D'UTILISATION DE CETTE MUSIQUE
---------------------------------------------------------------------------

* GENERALITES

Cette musique est distribu�e GRATUITEMENT afin que vous puissiez l'�couter
ou l'�diter avec plaisir.

Toutefois, son utilisation implique l'acceptation d'une licence et de
conditions d'utilisation sp�cifiques, telles que d�crites ci-dessous :
cette musique est distribu�e sous copyright selon le mod�le du "freeware",
et est en aucun cas vers�e dans le domaine public.

Les m�mes conditions d'utilisation s'appliquent � toutes les portions de
cette musique, y compris les sons et les instruments, sauf mention
contraire. Gardez � l'esprit que je peux � tout moment modifier ces
conditions sans pr�avis. La derni�re version officielle de cette licence
est disponible sur mon site Web � l'adresse http://www.arachnosoft.com.
Pensez � la consulter lorsque cela est n�cessaire.

* DISTRIBUTION

Vous �tes libre de distribuer cette musique � qui vous voulez, sous
n'importe quel format, du moment que vous teniez l'utilisateur final
inform� au sujet de la provenance de cette musique, de son auteur, et de
sa disponibilit� officielle sur mon site Web, http://www.arachnosoft.com.  

Si vous souhaitez distribuer cette musique dans un format diff�rent de
celui que je vous propose (MP3, OGG, etc.), j'aimerais que vous me
contactiez au pr�alable, de fa�on � me tenir inform� de l'utilisation de ma
musique.

Vous �tes bien entendu libre de distribuer cette musique sous sa forme
d'origine, telle que vous la trouvez sur mon site Web. Toutefois,
j'aimerais �galement en �tre tenu inform�.

Dans tous les cas, vous DEVEZ clairement sp�cifier que cette musique a �t�
produite par moi-m�me, Maxime Abbey, et que ses versions d'origine sont
disponibles dans leur plus r�cente mouture sur mon site,
http://www.arachnosoft.com.

De plus, la distribution doit �tre faite gratuitement, ou en �change d'un
faible montant mon�taire destin� � couvrir les frais de distribution et/ou
les supports utilis�s (CD-ROM, disques). Toute distribution commerciale est
couverte par les conditions d'utilisations commerciales de cette licence,
telles que d�crites ci-dessous.

* UTILISATION

Vous �tes enti�rement libre d'utiliser et d'�couter cette musique pour
votre plaisir personnel et de la convertir dans tout format destin� �
couvrir vos besoins d'�coute, du moment que cela ne cause pas de tort �
autrui, et que ce soit fait en conformit� avec les termes de cette licence.

Si vous souhaitez utiliser cette musique au sein de vos propres cr�ations
(logiciels, site Web, pr�sentation, CD-ROM, magazine, etc.), quel que soit
votre projet, veuillez me contacter afin de me tenir inform� � son sujet,
m�me si toute utilisation dans des projets non-commerciaux est encourag�e.
Toutefois, toute utilisation commerciale DOIT m'�tre signal�e avant toute
chose. Cela concerne aussi bien la musique en elle-m�me que les sons
qu'elle contient, puisque, sauf mention contraire, ils ont tous �t�
construits et enregistr�s par mes soins.

Vous �tes pleinement autoris� � modifier ou � remixer cette musique comme
vous l'entendez, mais si vous souhaitez distribuer une version modifi�e,
vous devez indiquer que vous avez utilis� cette musique comme base de
travail, et que vous �tes l'auteur de la version modifi�e. De plus, je
vous serais reconnaissant de me tenir inform� au sujet de vos travaux.

A PROPOS DE L'AUTEUR
---------------------------------------------------------------------------

Je m'appelle Maxime Abbey, je suis n� le 28 octobre 1985 en France.

Mon site Web est disponible � l'adresse http://www.arachnosoft.com. Vous y
retrouverez mes logiciels gratuits (dont des utilitaires et des jeux 2D/3D)
et l'ensemble de mes compositions musicales.

Pour toute demande, vous pouvez me contacter par e-mail � l'adresse
contact@arachnosoft.com. N'h�sitez pas � le faire, tous les e-mails que je
re�ois sont lus, et votre support est toujours appr�ci� !

POUR FINIR...
---------------------------------------------------------------------------

Merci d'�couter ma musique ! En esp�rant que vous l'appr�ciez...

J'aimerais �galement remercier toutes les personnes qui ont cr�� les outils
et les sons que j'ai utilis�s pour cette musique, et, en particulier,
Olivier Lapicque et toute l'�quipe de ModPlug Tracker / OpenMPT, ainsi que
Achraf Cherti, qui m'a fortement aid� � me frayer un chemin dans le monde
de la "tracked music".

Et bien entendu, merci � toutes les personnes, mentionn�es ou non, ayant
compos� la musique qui m'a inspir� pour produire celle-ci, directement ou
indirectement !

SUR CE, BONNE ECOUTE ! J'ATTENDS VOS COMMENTAIRES...
